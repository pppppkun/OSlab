#include "lib.h"
#include "types.h"

int main(void) {
	// TODO in lab4
	printf("philosopher\n");
	exit();
	return 0;
}
