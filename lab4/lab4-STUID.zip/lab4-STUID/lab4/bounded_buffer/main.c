#include "lib.h"
#include "types.h"

int main(void) {
	// TODO in lab4
	printf("bounded_buffer\n");
	exit();
	return 0;
}
