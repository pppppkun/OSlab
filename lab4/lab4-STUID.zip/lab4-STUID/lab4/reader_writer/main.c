#include "lib.h"
#include "types.h"

int main(void) {
	// TODO in lab4
	printf("reader_writer\n");
	exit();
	return 0;
}
